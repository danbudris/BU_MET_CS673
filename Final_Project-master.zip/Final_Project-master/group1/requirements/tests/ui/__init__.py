import test_authentication
import test_story
import test_projects
import test_iterations
import test_user_project_and_iteration_permission
# python manage.py test requirements.tests.ui
