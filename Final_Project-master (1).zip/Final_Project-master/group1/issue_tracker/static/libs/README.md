# Library directory for storing third party libraries for integration.
# Potential Example: jquery 
