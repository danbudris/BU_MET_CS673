
echo "comm: \n"
cloc comm/
echo "communication folder(ignore node modules): \n"
cloc communication/django
echo "group 1 folder: \n"
cloc group1/
echo "selenium tests folder: \n"
cloc selenium_tests/
echo "unit tests folder: \n"
cloc unit_tests/
echo "project_router folder: \n"
cloc project_router/

echo "manage.py file: \n"
cloc manage.py
echo "setting file: \n"
cloc settings.html
