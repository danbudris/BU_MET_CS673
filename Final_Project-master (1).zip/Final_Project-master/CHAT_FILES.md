API Routes - /group1/urls.py
Main.js - /group1/communication/node/main.js
Chat Jquery - /group1/comm/static/comm_tool.js
